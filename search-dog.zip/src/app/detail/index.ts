export * from './detail.component';
